package com.bluesun99.simpleteam;

import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerJoinEvent;

public class SimpleEventHandler implements Listener {
	@EventHandler
	public void onPlayerJoin(PlayerJoinEvent e)
	{
		Player ply = e.getPlayer();
		if (ply.hasMetadata("SimpleTeam_Team"))
			e.getPlayer().removeMetadata("SimpleTeam_Team", SimpleTeam.plugin);
	}
	
}
